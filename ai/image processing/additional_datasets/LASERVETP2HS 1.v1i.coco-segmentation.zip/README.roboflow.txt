
 LASERVETP2HS 1 - v1 2026-11-19 1:08am
==============================

This dataset was exported via roboflow.com on November 18, 2026 at 5:08 PM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 578 images.
Sarro are annotated in COCO Segmentation format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


